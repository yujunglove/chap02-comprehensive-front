
function Footer() {
    return (
        <footer className="footer">
            <p>Copyright 2023. team-greedy all rights reserved.</p>
        </footer>
    );
}

export default Footer;